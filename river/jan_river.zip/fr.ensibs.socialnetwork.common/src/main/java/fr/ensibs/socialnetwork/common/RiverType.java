package fr.ensibs.socialnetwork.common;

public abstract class RiverType {
    public static final int FRIEND = 1;
    public static final int INTEREST = 2;
    public static final int INTER_LIST = 3;
}
